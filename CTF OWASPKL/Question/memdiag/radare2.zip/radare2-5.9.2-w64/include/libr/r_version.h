#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R_MESON_VERSION "0.61.99"
#define R2_VERSION_MAJOR 5
#define R2_VERSION_MINOR 9
#define R2_VERSION_PATCH 2
#define R2_VERSION_NUMBER 50902
#define R2_VERSION_COMMIT 1
#define R2_VERSION "5.9.2"
#define R2_GITTAP "5.9.2"
#define R2_GITTIP "aea5c93a8f5a6ed360ea21d6a4e36f00accb8b7d"
#define R2_BIRTH "Mon 05/20/2024__23:16:31.82"
#endif
